# Steps to Publish the CRC-Aliases VSCode Extension

Because I am an idiot and can't remember how to do this every time...

## Step 1: Edit Your Extension

1. Make the necessary changes to your extension's code.
2. Save all changes.

## Step 2: Update `package.json`

1. Open `package.json`.
2. Increment the version number. For example, `1.0.0` to `1.0.1`:

    ```json
    {
      "name": "crc-aliases",
      "version": "1.0.1",
    }
    ```

3. Save the `package.json` file.

## Step 3: Compile Your Extension

1. Open a terminal or command prompt.
2. Navigate to the root directory of your extension project:

    ```sh
    cd path/to/your/extension/project
    ```

3. Run the compile command:

    ```sh
    npm run compile
    ```

## Step 4: Package Your Extension

1. Ensure you have VSCE (Visual Studio Code Extension Manager) installed globally by opening command-prompt and running this command `npm list -g vsce`. If `vsce` is installed globally, this command will show the version and location of the vsce package. If it is not installed, you will see a message indicating that it is not found and you will need to run this command `npm install -g @vscode/vsce`.

2. Package your extension *(this command will create a `.vsix` file in the current directory, which is your packaged extension)*:

    ```sh
    vsce package
    ```

## Step 5: Publish Your Extension

1. Login to VSCE (if you haven't already):

    ```sh
    vsce login KyleSanders
    ```

    *Note: If "KyleSanders" is recognized as a known-user, you are already logged in and you can choose to not to overwrite and move on to the "Publish your extension" step below. Otherwise, enter your Personal Access Token (PAT), when prompted.*

2. Publish your extension:

    ```sh
    vsce publish
    ```
