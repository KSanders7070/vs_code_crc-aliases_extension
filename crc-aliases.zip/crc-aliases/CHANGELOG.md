# Changelog

## [v1.0.2]

- ReadMe file updated with vital information for correct installation and use.
- Changelog updated (it was previously not updated with the prior release).

## [v1.0.1]

- Parentheses are no longer color-coded.
- Fixed issue with `$winds` showing as partially color-coded.

## [v1.0.0]

- Initial release.
